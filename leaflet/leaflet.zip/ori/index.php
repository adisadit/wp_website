<!--DEFAULT_WELCOME_PAGE--><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
    <head>
        <title>CloudMILD Webhosting</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link href="https://www.cloudmild.com/files/css-cloudmild.css" media="screen" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <div id="main">
            <div id="content">
                <div class="header">
                    <a id="logo" href="https://www.cloudmild.com/"><img src="https://www.cloudmild.com/images/default/logo.png" alt="Web hosting" /></a>
                </div>
                <div class="content">
                    <h1>Spesial untuk, Elida Nurrohmah :)</h1>
                    <p>Tinggal digunakan nih. Mm,, kalau butuh bantuan, bilang aja --"<br>Hehe</p>
      
                    <div class="clear"></div>
                </div>
                <div class="footer"></div>
                <div class="clear"></div>
            </div>
            <div id="footer">
                <div class="links">
                    <a href="https://www.cloudmild.co.id/hosting/personal.html" target="_blank">Personal WebHosting</a> 
                    <span class="pipe">|</span> 
                    <a href="https://www.cloudmild.co.id/hosting/enterprise.html" target="_blank">Enterprise WebHosting</a> 
                    <span class="pipe">|</span> 
                    <a href="https://www.cloudmild.co.id/domain-murah.html" target="_blank">Domain Murah</a> 
                    <span class="pipe">|</span> 
                    <a href="https://my.cloudmild.com/submitticket.php" target="_blank">Kirim Tiket</a>
                </div>
                <div class="copyright">Copyright &copy; 2014. CloudMILD. All Rights Reserved</div>
                <div class="social-icons">
                    <a href="http://www.facebook.com/CloudMILD"><img src="https://www.cloudmild.com/images/social/fb.png" /></a>
                    <a href="https://twitter.com/cloud_mild"><img src="https://www.cloudmild.com/images/social/twitter.png" /></a>
					<a href="https://plus.google.com/+CloudmildWebhosting"><img src="https://www.cloudmild.com/images/social/gplus.png" /></a>
                </div>
            </div>
        </div>
    </body>
</html>
<!--DEFAULT_WELCOME_PAGE-->
